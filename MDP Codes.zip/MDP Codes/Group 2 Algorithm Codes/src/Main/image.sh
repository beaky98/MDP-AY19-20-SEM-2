source /Users/hannancao/Desktop/models/research/object_detection/MDP/bin/activate
which python3
python3 /Users/hannancao/Desktop/CZ3004/Updated_Group_2_Algorithm_Codes/src/Main/object_detection/Object_detection_imageTest.py
pwd
